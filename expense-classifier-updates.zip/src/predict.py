from pathlib import Path
import joblib

MODEL_PATH = (
    Path(__file__).resolve().parents[1]
    / "models"
    / "expense_classifier_final.joblib"
)

_model = None


class UnrecognizedDescription(ValueError):
    """The description has no features in any fitted vocabulary."""


def predict(text):
    global _model

    if not isinstance(text, str) or not text.strip():
        raise ValueError("Enter a non-empty description.")

    if _model is None:
        _model = joblib.load(MODEL_PATH)

    description = [text.strip()]
    if all(
        fold.estimator.named_steps["tfidf"].transform(description).nnz == 0
        for fold in _model.calibrated_classifiers_
    ):
        raise UnrecognizedDescription("Add what you bought or paid for so the model can classify it.")

    probabilities = _model.predict_proba(description)[0]
    best_index = probabilities.argmax()

    return {
        "category": str(_model.classes_[best_index]),
        "confidence": float(probabilities[best_index])
    }
